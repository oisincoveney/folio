# momokaya-chart

Shared Helm **library chart** for the Momokaya fleet's cluster-sync dev loop
(INFRA-075).

It owns the building blocks every app chart was hand-copying:

- the dev `Deployment` / `Service` / `Ingress` templates,
- the `momokaya:` labels/annotations block,
- the okteto-aware `.spec.replicas` gate (omit `replicas` in dev so helm-4
  server-side-apply does not conflict with okteto's field ownership).

## Use

Add the dependency, then render the whole dev-loop manifest set from a single
template that iterates the `components` list (component-as-data — no per-workload
copied templates):

```yaml
# <app>/chart/Chart.yaml
dependencies:
  - name: momokaya-chart
    version: ">=0.1.0"
    repository: oci://ghcr.io/oisin-ee/charts   # publishing home TBD (INFRA-075.06)
```

```yaml
# <app>/chart/templates/workloads.yaml
{{- include "momokaya-chart.workloads" . }}
```

```yaml
# <app>/chart/values.dev.yaml  (replicaCount unset => okteto owns .spec.replicas)
components:
  - name: api
    componentLabel: api
    nameSuffix: ""          # primary component => bare fullname
    port: 8080
    image: { repository: ghcr.io/oisin-ee/<app>/api, tag: latest, pullPolicy: Always }
    pullSecretName: ghcr-pull-secret
    podSecurityContext: { runAsNonRoot: false }
    env:
      - { name: PORT, value: "8080" }
    ingress: { enabled: true, host: <app>-dev.momokaya.ee }
```

Set `replicaCount` on a component in production overlays to render
`.spec.replicas`; leave it unset in dev so okteto keeps server-side-apply
ownership of the field. The full component key reference is in
`templates/_deployment.tpl`.

Templates landed under `INFRA-075.03`. Publishing home (OCI registry) is
`INFRA-075.06`.
