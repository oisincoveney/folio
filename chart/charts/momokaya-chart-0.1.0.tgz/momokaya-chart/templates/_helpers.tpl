{{/*
  Aggregator helpers — the public seam consumer charts actually `include`.

  "Component is data" lives here: a consumer's whole dev-loop manifest set is a
  single `include "momokaya-chart.workloads" .` over the `.Values.components`
  list. Each list entry is a component dict (see _deployment.tpl for keys); the
  helper renders that component's Deployment + Service (+ Ingress when enabled),
  document-separated. No per-component copied templates anywhere in the consumer.

  A consumer that wants one named component instead can call
  `momokaya-chart.workload` with an explicit {root, component} dict.
*/}}

{{/* One component → Deployment + Service + Ingress (Ingress self-gates). */}}
{{- define "momokaya-chart.workload" -}}
{{- include "momokaya-chart.deployment" . }}
---
{{ include "momokaya-chart.service" . }}
{{- $ingress := include "momokaya-chart.ingress" . }}
{{- with trim $ingress }}
---
{{ . }}
{{- end }}
{{- end -}}

{{/* Every entry in .Values.components → its full workload set. */}}
{{- define "momokaya-chart.workloads" -}}
{{- $root := . -}}
{{- range $i, $component := .Values.components }}
{{- if $i }}
---
{{ end }}
{{- include "momokaya-chart.workload" (dict "root" $root "component" $component) }}
{{- end }}
{{- end -}}
