{{/*
  momokaya-chart.ingress — single-host Ingress routing to one component's
  Service. Renders nothing unless `component.ingress.enabled` AND a host is set,
  so a backend-only component (worker) simply omits the ingress block. Takes the
  {root, component} dict.

  `component.ingress` keys:
    enabled         (req-ish) render only when true
    host            (req)     the public host
    className                 ingressClassName (default: root .Values.ingress.className)
    path                      (default "/")   pathType (default "Prefix")
    annotations               extra annotations ({})
    tls                       raw tls block ([]); when set with a host and no
                              entries, no implicit cert is created — callers pass
                              their own (cert-manager issuer annotation is the
                              app's choice, kept in annotations).
*/}}
{{- define "momokaya-chart.ingress" -}}
{{- $root := .root -}}
{{- $component := .component -}}
{{- $ingress := default dict $component.ingress -}}
{{- if and $ingress.enabled $ingress.host -}}
{{- $className := $ingress.className -}}
{{- if not $className -}}
{{- with $root.Values.ingress -}}{{- $className = .className -}}{{- end -}}
{{- end -}}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ include "momokaya-chart.componentName" . }}
  labels:
    {{- include "momokaya-chart.labels" . | nindent 4 }}
  {{- with $ingress.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- with $className }}
  ingressClassName: {{ . }}
  {{- end }}
  {{- with $ingress.tls }}
  tls:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  rules:
    - host: {{ $ingress.host | quote }}
      http:
        paths:
          - path: {{ default "/" $ingress.path }}
            pathType: {{ default "Prefix" $ingress.pathType }}
            backend:
              service:
                name: {{ include "momokaya-chart.componentName" . }}
                port:
                  name: http
{{- end -}}
{{- end -}}
