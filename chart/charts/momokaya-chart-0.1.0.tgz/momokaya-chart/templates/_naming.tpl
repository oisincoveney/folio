{{/*
  Naming + chart-version helpers. A LIBRARY chart owns no .Values of its own and
  must never assume the consumer's release/chart context shape beyond the helm
  built-ins (.Release, .Chart). These mirror the per-repo charts so a consumer
  that drops its hand-written copies keeps byte-identical names/labels.

  All public helpers below take a SINGLE dict argument with two keys:
    root      — the consumer chart's root context (`.`), for .Release/.Chart.
    component — the per-component values dict (see values.yaml `components`).
  This is the one place the "component is data" shape is enforced: variation
  rides in `component`, never in copy-pasted blocks.
*/}}

{{/* Chart name, overridable, DNS-truncated. Operates on the root context. */}}
{{- define "momokaya-chart.name" -}}
{{- $root := . -}}
{{- default $root.Chart.Name $root.Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
  Fully-qualified release name, overridable. Matches the identical helper in
  every consumer chart (jalgpall-data/jalgpall-web/momokaya/rondo): if the
  release name already contains the chart name, use it as-is, else prefix it.
*/}}
{{- define "momokaya-chart.fullname" -}}
{{- $root := . -}}
{{- if $root.Values.fullnameOverride -}}
{{- $root.Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default $root.Chart.Name $root.Values.nameOverride -}}
{{- if contains $name $root.Release.Name -}}
{{- $root.Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" $root.Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
  Per-component resource name: `<fullname>-<component>`. A component named the
  same as the chart (e.g. the primary "web"/"api") may set `nameSuffix: ""` to
  collapse to the bare fullname, matching charts whose primary Deployment is
  unsuffixed (jalgpall-data api, rondo api).
*/}}
{{- define "momokaya-chart.componentName" -}}
{{- $root := .root -}}
{{- $component := .component -}}
{{- $base := include "momokaya-chart.fullname" $root -}}
{{- $suffix := default $component.name $component.nameSuffix -}}
{{- if $suffix -}}
{{- printf "%s-%s" $base $suffix | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $base -}}
{{- end -}}
{{- end -}}

{{/* Image reference: `repository:tag`, or bare repository when tag is unset. */}}
{{- define "momokaya-chart.imageRef" -}}
{{- if .tag -}}
{{- printf "%s:%s" .repository .tag -}}
{{- else -}}
{{- .repository -}}
{{- end -}}
{{- end -}}
