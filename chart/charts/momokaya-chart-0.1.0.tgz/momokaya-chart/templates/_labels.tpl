{{/*
  Standard label + annotation blocks shared by every Momokaya workload. The
  `momokaya.ee/*` labels and annotations are kept OUT of selectorLabels: they
  vary per ephemeral environment (env-id, sha, owner, ...), and selectors are
  immutable on a Deployment, so a per-env value there would wedge upgrades.

  Each public helper takes the {root, component} dict. `component.componentLabel`
  (e.g. "api"/"web"/"app-web") is the app.kubernetes.io/component value used to
  disambiguate workloads that share the chart name (so a Service selecting on it
  won't load-balance across unrelated pods — the rondo/CNPG/Garage case).
*/}}

{{/* helm.sh/chart label value. */}}
{{- define "momokaya-chart.chart" -}}
{{- $root := . -}}
{{- printf "%s-%s" $root.Chart.Name $root.Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
  Selector labels — the immutable identity match. name+instance, plus the
  component label so each workload's Service/Deployment selects only its pods.
*/}}
{{- define "momokaya-chart.selectorLabels" -}}
{{- $root := .root -}}
{{- $component := .component -}}
app.kubernetes.io/name: {{ include "momokaya-chart.name" $root }}
app.kubernetes.io/instance: {{ $root.Release.Name }}
{{- with $component.componentLabel }}
app.kubernetes.io/component: {{ . }}
{{- end }}
{{- end -}}

{{/*
  Common metadata labels: chart/version/managed-by + selector labels + the
  momokaya env labels. Safe on metadata (not selectors).
*/}}
{{- define "momokaya-chart.labels" -}}
{{- $root := .root -}}
helm.sh/chart: {{ include "momokaya-chart.chart" $root }}
{{ include "momokaya-chart.selectorLabels" . }}
{{- with $root.Values.partOf }}
app.kubernetes.io/part-of: {{ . }}
{{- end }}
{{- if $root.Chart.AppVersion }}
app.kubernetes.io/version: {{ $root.Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ $root.Release.Service }}
{{ include "momokaya-chart.momokayaLabels" $root -}}
{{- end -}}

{{/* momokaya.ee/* environment labels — per-env, metadata only. */}}
{{- define "momokaya-chart.momokayaLabels" -}}
{{- with .Values.momokaya -}}
{{- if .repo }}
momokaya.ee/repo: {{ .repo | quote }}
{{- end }}
{{- if .envKind }}
momokaya.ee/env-kind: {{ .envKind | quote }}
{{- end }}
{{- if .envId }}
momokaya.ee/env-id: {{ .envId | quote }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
  momokaya.ee/* annotations — provenance + ephemeral-env lifecycle + per-url
  metadata. Mirrors the rondo/momokaya momokayaAnnotations helper so the
  ephemeral-env controller reads the same keys regardless of source chart.
*/}}
{{- define "momokaya-chart.momokayaAnnotations" -}}
{{- with .Values.momokaya -}}
{{- if .branch }}
momokaya.ee/branch: {{ .branch | quote }}
{{- end }}
{{- if .sha }}
momokaya.ee/sha: {{ .sha | quote }}
{{- end }}
{{- if .owner }}
momokaya.ee/owner: {{ .owner | quote }}
{{- end }}
{{- if .ticket }}
momokaya.ee/ticket: {{ .ticket | quote }}
{{- end }}
{{- if .epic }}
momokaya.ee/epic: {{ .epic | quote }}
{{- end }}
{{- with .cleanupPolicy }}
{{- if .ttl }}
momokaya.ee/cleanup-policy: {{ .ttl | quote }}
{{- end }}
{{- if .deleteAfter }}
momokaya.ee/delete-after: {{ .deleteAfter | quote }}
{{- end }}
{{- if hasKey . "retainOnFailure" }}
momokaya.ee/retain-on-failure: {{ .retainOnFailure | quote }}
{{- end }}
{{- end }}
{{- if .queueName }}
momokaya.ee/queue-name: {{ .queueName | quote }}
{{- end }}
{{- range $name, $url := .urls }}
{{- if $url.host }}
momokaya.ee/url.{{ $name }}: {{ printf "https://%s%s" $url.host (default "/" $url.path) | quote }}
{{- end }}
{{- if $url.service }}
momokaya.ee/url.{{ $name }}.service: {{ $url.service | quote }}
{{- end }}
{{- if $url.port }}
momokaya.ee/url.{{ $name }}.port: {{ $url.port | quote }}
{{- end }}
{{- if $url.kind }}
momokaya.ee/url.{{ $name }}.kind: {{ $url.kind | quote }}
{{- end }}
{{- if $url.readiness }}
momokaya.ee/url.{{ $name }}.readiness: {{ $url.readiness | quote }}
{{- end }}
{{- if $url.status }}
momokaya.ee/url.{{ $name }}.status: {{ $url.status | quote }}
{{- end }}
{{- if $url.exposure }}
momokaya.ee/url.{{ $name }}.exposure: {{ $url.exposure | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}
