{{/*
  momokaya-chart.service — ClusterIP Service fronting one component. Selects on
  the same selectorLabels (incl. component label) as its Deployment so it never
  load-balances onto sibling workloads sharing the chart name. Takes the
  {root, component} dict.

  `component` keys used:
    name / componentLabel / nameSuffix  (see _naming/_labels)
    port            (req) Service port; targetPort is the named "http" port
    service.type          Service type (default ClusterIP)
*/}}
{{- define "momokaya-chart.service" -}}
{{- $component := .component -}}
{{- $service := default dict $component.service -}}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "momokaya-chart.componentName" . }}
  labels:
    {{- include "momokaya-chart.labels" . | nindent 4 }}
spec:
  type: {{ default "ClusterIP" $service.type }}
  ports:
    - name: http
      port: {{ $component.port }}
      targetPort: http
      protocol: TCP
  selector:
    {{- include "momokaya-chart.selectorLabels" . | nindent 4 }}
{{- end -}}
