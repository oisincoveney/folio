{{/*
  momokaya-chart.deployment — the dev Deployment every consumer chart was
  hand-writing. Takes the {root, component} dict; ALL per-component variation
  (name, image, port, env, probes, securityContext, scheduling) rides in
  `component`, so adding a workload is one more data entry, never another copied
  template.

  THE LOAD-BEARING GATE (.spec.replicas):
    `{{- with $component.replicaCount }}replicas: {{ . }}{{- end }}`
  In dev `replicaCount` is unset/null, so the field is OMITTED. okteto's inner
  loop owns .spec.replicas (it scales the Deployment to 0 and runs the synced
  clone). If helm templated `replicas` here, helm-4 server-side-apply would lose
  field ownership and every `helm upgrade` (each `mise run dev` re-run) would
  fail with `conflict with "okteto" using apps/v1: .spec.replicas`. Production
  sets replicaCount and the field renders normally — same rule as helm+HPA
  coexistence: never template a field an external controller owns.

  `component` keys:
    name            (req) component id, e.g. "api" | "web" | "app-web"
    componentLabel        app.kubernetes.io/component value (default: name)
    nameSuffix            resource-name suffix (default: name; "" => bare fullname)
    replicaCount          INT to render replicas; unset/null => field omitted (dev)
    image           (req) {repository, tag, pullPolicy}
    pullSecretName        imagePullSecrets[0].name when set
    containerName         container name (default: name)
    port            (req) containerPort (named "http")
    command / args        container entrypoint overrides
    env                   raw env list ([]) spliced verbatim
    envFrom               raw envFrom list ([])
    probes                {readiness, liveness} raw probe specs; default to an
                          httpGet on `probePath` (default "/health") at the port
    probePath             default httpGet path for both probes (default /health)
    podSecurityContext    pod-level securityContext ({})
    securityContext       container securityContext ({})
    resources             container resources ({})
    podAnnotations        ({})  podLabels ({})
    nodeSelector / affinity / tolerations
    annotations           extra Deployment-metadata annotations ({})
*/}}
{{- define "momokaya-chart.deployment" -}}
{{- $root := .root -}}
{{- $component := .component -}}
{{- $probePath := default "/health" $component.probePath -}}
{{- $probes := default dict $component.probes -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "momokaya-chart.componentName" . }}
  labels:
    {{- include "momokaya-chart.labels" . | nindent 4 }}
  {{- with $component.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- with $component.replicaCount }}
  replicas: {{ . }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "momokaya-chart.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels:
        {{- include "momokaya-chart.selectorLabels" . | nindent 8 }}
        {{- include "momokaya-chart.momokayaLabels" $root | nindent 8 }}
        {{- with $component.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      {{- $podAnnotations := include "momokaya-chart.momokayaAnnotations" $root }}
      {{- with $component.podAnnotations }}
      {{- $podAnnotations = printf "%s\n%s" $podAnnotations (toYaml .) }}
      {{- end }}
      {{- with trim $podAnnotations }}
      annotations:
        {{- . | nindent 8 }}
      {{- end }}
    spec:
      {{- with $component.pullSecretName }}
      imagePullSecrets:
        - name: {{ . | quote }}
      {{- end }}
      {{- with $component.podSecurityContext }}
      securityContext:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      containers:
        - name: {{ default $component.name $component.containerName }}
          image: {{ include "momokaya-chart.imageRef" $component.image | quote }}
          imagePullPolicy: {{ $component.image.pullPolicy }}
          {{- with $component.command }}
          command:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with $component.args }}
          args:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          ports:
            - name: http
              containerPort: {{ $component.port }}
              protocol: TCP
          {{- with $component.envFrom }}
          envFrom:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with $component.env }}
          env:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          readinessProbe:
            {{- with $probes.readiness }}
            {{- toYaml . | nindent 12 }}
            {{- else }}
            httpGet:
              path: {{ $probePath }}
              port: http
            {{- end }}
          livenessProbe:
            {{- with $probes.liveness }}
            {{- toYaml . | nindent 12 }}
            {{- else }}
            httpGet:
              path: {{ $probePath }}
              port: http
            {{- end }}
          {{- with $component.securityContext }}
          securityContext:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with $component.resources }}
          resources:
            {{- toYaml . | nindent 12 }}
          {{- end }}
      {{- with $component.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $component.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $component.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end -}}
